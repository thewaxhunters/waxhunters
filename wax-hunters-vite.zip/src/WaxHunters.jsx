
// Wax Hunters - React Starter

import React, { useState } from 'react';
// Simplified UI (no external imports)
const Button = ({ onClick, children }) => (
  <button style={{ padding: '0.5rem 1rem', margin: '0.5rem', cursor: 'pointer' }} onClick={onClick}>{children}</button>
);
const Card = ({ children }) => (
  <div style={{ border: '1px solid #ccc', padding: '1rem', marginBottom: '1rem', borderRadius: '8px', background: '#fff' }}>{children}</div>
);
const CardContent = ({ children }) => <div>{children}</div>;

const cities = ["New York", "Chicago", "Dallas", "Atlanta", "Los Angeles"];
const startingBankroll = 1000;
const weeklyMarketTrends = [1.0, 0.95, 1.1, 1.2, 0.85];

const getRandomCity = () => cities[Math.floor(Math.random() * cities.length)];

const allSellers = [
  {
    name: "Coop",
    intro: "Got some heat if you know what you're looking for.",
    items: [
      { name: "1986 Fleer Jordan Rookie", price: 700, fake: false },
      { name: "Mystery Wax Box", price: 250, fake: true },
    ]
  }
];

const getRandomSellers = () => {
  const shuffled = [...allSellers].sort(() => 0.5 - Math.random());
  return shuffled.slice(0, 1);
};

const WaxHunters = () => {
  const [week, setWeek] = useState(1);
  const [city, setCity] = useState(getRandomCity());
  const [bank, setBank] = useState(startingBankroll);
  const [inventory, setInventory] = useState([]);
  const [marketValues, setMarketValues] = useState([]);
  const [dialogue, setDialogue] = useState("");
  const [sellers, setSellers] = useState(getRandomSellers());
  const [showCardShow, setShowCardShow] = useState(false);

  const buyItem = (item, sellerIndex) => {
    if (bank < item.price) return alert("Not enough funds");
    setBank(prev => prev - item.price);
    setInventory(prev => [...prev, { ...item, weekObtained: week, appraised: false }]);
    setSellers(prev => {
      const updated = [...prev];
      updated[sellerIndex] = {
        ...updated[sellerIndex],
        items: updated[sellerIndex].items.filter(i => i.name !== item.name)
      };
      return updated;
    });
  };

  const gradeInventory = () => {
    const gradingFee = 20;
    if (bank < gradingFee) {
      setDialogue("Not enough funds to grade your inventory.");
      return;
    }
    setBank(prev => prev - gradingFee);

    let updated = inventory.map((card, i) => {
      const grade = Math.floor(Math.random() * 10) + 1;
      let note = `Graded ${grade}/10`;
      let newMarket = marketValues[i] || card.price;
      if (grade >= 6) newMarket = Math.floor(newMarket * (1 + (grade - 5) * 0.1));
      else if (grade === 5) newMarket = Math.floor(newMarket);
      else newMarket = Math.floor(newMarket * 0.6);
      return { ...card, graded: true, grade, note, appraisedMarket: newMarket };
    });
    setInventory(updated);
    setMarketValues(updated.map(item => item.appraisedMarket || item.price));
    setDialogue("Your cards have been graded. Grading cost: $20");
  };

  const sellItems = () => {
    const total = inventory.reduce((acc, item, i) => {
      const base = marketValues[i] || item.price;
      const variance = Math.random() * 0.1 - 0.05;
      const finalSale = base * (1 + variance);
      const adjusted = finalSale * (item.fake ? 0.3 : 1);
      return acc + adjusted;
    }, 0);
    setBank(bank + Math.floor(total));
    setInventory([]);
    setMarketValues([]);
    setDialogue(`You sold your cards for $${Math.floor(total)}.`);
    nextWeek();
  };

  const nextWeek = () => {
    const newWeek = week + 1;
    setWeek(newWeek);
    setCity(getRandomCity());
    setSellers(getRandomSellers());
    setShowCardShow(newWeek % 4 === 0);

    setMarketValues(
      inventory.map(item => {
        const weeksHeld = newWeek - item.weekObtained;
        const currentBase = marketValues[inventory.indexOf(item)] || item.price;
        const seasonalTrend = Math.sin((weeksHeld / 52) * 2 * Math.PI) * 0.15;
        const randomShift = Math.random() * 0.05 - 0.025;
        const finalMultiplier = 1 + seasonalTrend + randomShift;
        return Math.round(currentBase * finalMultiplier);
      })
    );
  };

  return (
    <div>
      <h1>Wax Hunters</h1>
      <p>Week {week} – City: {city}</p>
      <p>Bank: ${bank}</p>
      {sellers.map((seller, index) => (
        <Card key={index}>
          <CardContent>
            <p><strong>{seller.name}</strong>: {seller.intro}</p>
            {seller.items.map(item => (
              <div key={item.name}>
                <p>{item.name} – ${item.price}</p>
                <Button onClick={() => buyItem(item, index)}>Buy</Button>
              </div>
            ))}
          </CardContent>
        </Card>
      ))}
      <Button onClick={gradeInventory}>Grade Inventory</Button>
      <Button onClick={sellItems}>Sell Inventory</Button>
      <Button onClick={nextWeek}>Next Week</Button>
      <h2>Inventory</h2>
      <ul>
        {inventory.map((item, i) => (
          <li key={i}>{item.name} – Bought for ${item.price}, Value: ${marketValues[i] || item.price} {item.graded ? `(${item.note})` : ""}</li>
        ))}
      </ul>
      <p><em>{dialogue}</em></p>
    </div>
  );
};

export default WaxHunters;
